VERNIER CALLIPER - FIX 2
Upload index.html and script.js to the repository root (keep verniercaliper.glb in the same folder).
Changes: Jaw View centred on the jaws; stronger + / - zoom; zero error now moves the main scale against the vernier zero so closed jaws and object readings show it; Remove Object sits in the Objects panel; How it works opens from Learn and every ^ header toggles; extra duplicate scale rows removed.
Not changed: the caliper's look (still the Sketchfab model).
